clear; clc;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%% set age range, T1 < T2 %%%%%%%%%%%%%%%%%%%%%%%%%%

% T1 = 1740;  T2 = 1790;
T1 = 1425;  T2 = 1485;
% T1 = 1040;  T2 = 1095;

%%%%%%%%%%%%%%%%%%%%% number of bootstrap resampling %%%%%%%%%%%%%%%%%%%%%%

bsnum=2000;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% import paleomagnetic data %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd('..');cd('pmag_data')

D_Lau = readmatrix('Dir_Laurentia_all.csv','Range','B2:M38');
D_Bal = readmatrix('Dir_Baltica_all.csv','Range','B2:M38');
D_Al = readmatrix('Dir_Aldan_all.csv','Range','B2:M38');
D_An = readmatrix('Dir_Anabar_all.csv','Range','B2:M38');

Age_Lau=D_Lau(:,1); Slat_Lau=D_Lau(:,4); Slon_Lau=D_Lau(:,5);
Dec_Lau=D_Lau(:,6); Inc_Lau=D_Lau(:,7);
Err_Lau=D_Lau(:,8); Wgt_Lau=D_Lau(:,12);

Age_Bal=D_Bal(:,1); Slat_Bal=D_Bal(:,4); Slon_Bal=D_Bal(:,5);
Dec_Bal=D_Bal(:,6); Inc_Bal=D_Bal(:,7);
Err_Bal=D_Bal(:,8); Wgt_Bal=D_Bal(:,12);

Age_Al=D_Al(:,1); Slat_Al=D_Al(:,4); Slon_Al=D_Al(:,5);
Dec_Al=D_Al(:,6); Inc_Al=D_Al(:,7);
Err_Al=D_Al(:,8); Wgt_Al=D_Al(:,12);

Age_An=D_An(:,1); Slat_An=D_An(:,4); Slon_An=D_An(:,5);
Dec_An=D_An(:,6); Inc_An=D_An(:,7);
Err_An=D_An(:,8); Wgt_An=D_An(:,12);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% Euler rotation parameters %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% plates are rotated with respect to Laurentia reference frame %%%%%%

Elat_Lau=0;         Elon_Lau=0;         Eang_Lau=0.0;                       % Laurentia to absolute
Elat_Bal=47.5;      Elon_Bal=1.5;       Eang_Bal=49.0;                      % Baltica to Laurentia Evans+11
Elat_Al=78.0;       Elon_Al=118.3;      Eang_Al=170.7;                      % Aldan   to Laurentia Evans+11
Elat_An=78.0;       Elon_An=99.0;       Eang_An=147.0;                      % Anabar  to Laurentia Evans+11
% Elat_Al=61.0;       Elon_Al=317.0;      Eang_Al=81.0;                     % Aldan   to Laurentia Sears+22
% Elat_An=61.0;       Elon_An=317.0;      Eang_An=81.0;                     % Anabar  to Laurentia Sears+22
% Elat_Al=-67.3;      Elon_Al=-44.7;      Eang_Al=-151.5;                   % Aldan   to Laurentia Pisarevsky+14
% Elat_An=-70.0;      Elon_An=-46.8;      Eang_An=-127.0;                   % Anabar  to Laurentia Pisarevsky+14

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% start forward modeling to get best-fit field orientation %%%%%%%%q
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd('..');cd('best_fit')

%%%%% rotate Slat, Slon and declination to Laurentia reference frame %%%%%%

[Slat_Lau_r,Slon_Lau_r]=Eulerrot(Slat_Lau,Slon_Lau,Elat_Lau,Elon_Lau,Eang_Lau);
[Dec_Lau_r]=rotDec(Slat_Lau,Slon_Lau,Dec_Lau,Elat_Lau,Elon_Lau,Eang_Lau);

[Slat_Bal_r,Slon_Bal_r]=Eulerrot(Slat_Bal,Slon_Bal,Elat_Bal,Elon_Bal,Eang_Bal);
[Dec_Bal_r]=rotDec(Slat_Bal,Slon_Bal,Dec_Bal,Elat_Bal,Elon_Bal,Eang_Bal);

[Slat_Al_r,Slon_Al_r]=Eulerrot(Slat_Al,Slon_Al,Elat_Al,Elon_Al,Eang_Al);
[Dec_Al_r]=rotDec(Slat_Al,Slon_Al,Dec_Al,Elat_Al,Elon_Al,Eang_Al);

[Slat_An_r,Slon_An_r]=Eulerrot(Slat_An,Slon_An,Elat_An,Elon_An,Eang_An);
[Dec_An_r]=rotDec(Slat_An,Slon_An,Dec_An,Elat_An,Elon_An,Eang_An);

%%%%%%%%%%%%%%%%%%%%%%%%%% data combination %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

D_Lau_r=[Age_Lau,Slat_Lau_r,Slon_Lau_r,Dec_Lau_r,Inc_Lau,Err_Lau,Wgt_Lau];
D_Bal_r=[Age_Bal,Slat_Bal_r,Slon_Bal_r,Dec_Bal_r,Inc_Bal,Err_Bal,Wgt_Bal];
D_Al_r=[Age_Al,Slat_Al_r,Slon_Al_r,Dec_Al_r,Inc_Al,Err_Al,Wgt_Al];
D_An_r=[Age_An,Slat_An_r,Slon_An_r,Dec_An_r,Inc_An,Err_An,Wgt_An];

%%%%%%%%%%%%%%%%%%% final input data to forward modeling %%%%%%%%%%%%%%%%%%

% DATA=D_Lau_r;                                          % Laurentia only
% DATA=cat(1,D_Lau_r,D_Bal_r);                           % Laurentia + Baltica only
% DATA=cat(1,D_Lau_r,D_Al_r,D_An_r);                     % Laurentia + Siberia only
DATA=cat(1,D_Lau_r,D_Bal_r,D_Al_r,D_An_r);             % Laurentia + Baltica + Siberia

%%%%%%%%%%%%%%%%%%% filter data based on age and weight %%%%%%%%%%%%%%%%%%%

DT = DATA(:,1);  DLAT = DATA(:,2);  DLON = DATA(:,3);
DD = DATA(:,4);  DI = DATA(:,5);    DERR = DATA(:,6);  DWT = DATA(:,7);
nidx = (DT<=T2).*(DT>=T1).*(DWT>0);  nidx = (nidx>0);
data = [DLAT(nidx),DLON(nidx),DD(nidx),DI(nidx),DERR(nidx)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% bootstrap resampling setup %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd('..');cd('monte_carlo')

n=length(data(:,1));
minres=zeros(bsnum,1);
cstore=zeros(bsnum,n);

% predictions and comparisons
Tn = pi*(0.0:0.02:2.0);       % longitude grid
Ln = pi*(0.0:0.02:1.0);       % colatitude grid

[TN,LN] = meshgrid(Tn,Ln);

rad=pi/180;

for k=1:1:bsnum

    res = zeros(size(TN));

%   c=randsample((1:n),n,true,DWT(nidx))';
    
%   data_ptb=data(c,:);

    data_ptb=data;

    Derr = asin(sin(data_ptb(:,5).*rad)./cos(data_ptb(:,4).*rad))./rad;
    Ierr = data_ptb(:,5);

    data_ptb(:,3) = data_ptb(:,3) + randn(size(data_ptb(:,3))).*Derr;
    data_ptb(:,4) = data_ptb(:,4) + randn(size(data_ptb(:,4))).*Ierr;

    for i = 1:length(Tn)
        for j = 1:length(Ln)
            res(j,i) = bestpreddipole(Tn(i),Ln(j),data_ptb);
        end
    end

%   cstore(k,:)=c';

    res1 = res(:);
    minres(k,1)=min(res1);
    
    % keep track of the calculation
    if k==1
        disp(['k=' num2str(k) '  t=' char(datetime('now','Format','HH:mm:ss'))]);
    elseif mod(k,50) == 0
        disp(['k=' num2str(k) '  t=' char(datetime('now','Format','HH:mm:ss'))]);
    end

end

% plot histogram with statistics

figure (1)
set(gcf,'position',[0,600,600,500])
histogram(minres);

mean_res=mean(minres);
std_res=std(minres);

title1=['Dipole Forward Modeling ' num2str(T2) '-' num2str(T1) ' Ma'];
title2=['minimum residual = ', num2str(mean_res,'%.1f') '° ' '\pm ', num2str(std_res,'%.1f') '°'];
title3=['number of bootstrap resampling = ', num2str(bsnum)];
t=title({title1 title2 title3});
t.FontSize = 12;

% save data in csv spreadsheet

filetitle=['Dipole Lau Bal Sib ' num2str(T2) '-' num2str(T1) ' Ma'];
writematrix(minres,[filetitle,'.csv']);
