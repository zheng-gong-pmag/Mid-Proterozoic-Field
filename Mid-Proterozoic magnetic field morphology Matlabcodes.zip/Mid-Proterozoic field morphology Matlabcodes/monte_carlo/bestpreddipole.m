function res = bestpreddipole(Tn,Ln,data)
    % read the data
    lat = data(:,1);  Ls = (pi/180)*(90-lat);  
    lon = data(:,2);  Ts = (pi/180)*lon;
    Dm = (pi/180)*data(:,3);   
    Im = (pi/180)*data(:,4);
    err = (pi/180)*data(:,5); 
    ndata = length(lat);
    
    % make predictions and compare with data
    Tp = 0;
    res = zeros(ndata,1);
    [A,invA] = transmatrix(Tn,Ln,Tp);
    for n = 1:ndata
        Mp = M_paleo_dipole(A,invA,lat(n),lon(n));
        Mm = Mdir(Ls(n),Ts(n),Dm(n),Im(n));
        res(n) = acos(Mp'*Mm);
    end 
    res = 180/pi*sqrt((res'*res)/ndata);
end