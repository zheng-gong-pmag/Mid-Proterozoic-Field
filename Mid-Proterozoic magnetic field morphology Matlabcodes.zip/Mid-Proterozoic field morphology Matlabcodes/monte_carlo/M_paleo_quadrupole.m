function M = M_paleo_quadrupole(A,invA,lat,lon)
    % present position vector
    Ts = (pi/180)*lon;
    Ls = (pi/180)*(90-lat);  
    xs = sin(Ls)*cos(Ts);
    ys = sin(Ls)*sin(Ts);
    zs = cos(Ls);  Xs = [xs;ys;zs];
    % paleo position vector
    X = A*Xs;  x = X(1);  
    y = X(2);  z = X(3);
    % calculate paleo longitude and colatitude
    cosL = z;  L = acos(z);
    T = atan(y/x)+pi*(x<0);  cosT = x/sin(L);  
    ez = X;  ey = [-cos(L)*cos(T); -cos(L)*sin(T); sin(L)];
    ex = [ey(2)*ez(3)-ey(3)*ez(2); ey(3)*ez(1)-ey(1)*ez(3); ey(1)*ez(2)-ey(2)*ez(1)];
    % calculate the direction vector
    Mz = 3*cos(2*T)*sin(L)^2;
    My = cos(2*T)*sin(2*L);
    Mx = 2*sin(2*T)*sin(L);
    M = Mx*ex+My*ey+Mz*ez;  
    M = M/sqrt(M'*M);  M = invA*M;
end