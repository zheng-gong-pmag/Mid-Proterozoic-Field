fig10=figure(10);
set(gcf,'position',[600,0,600,600])
m_proj('ortho','lat',60','long',270');

m_contourf(Lon,Lat,Id/rad,Inclev);
clim([-90,90]); colormap(redblue); hcb = colorbar; ylabel(hcb, 'Inclination (°)');
axis equal
m_grid('yticklabels',[],...
       'xticklabels',[],'linestyle','none','xtick',12,'ytick',9,'ticklen',0);

exportgraphics(fig10,'reconstruction6.pdf','ContentType','vector')