 function [M,Dp,Ip] = DI_paleo_dipole(A,invA,lat,lon)
    % present position vector
    Ts = (pi/180)*lon;
    Ls = (pi/180)*(90-lat);  
    xs = sin(Ls)*cos(Ts);
    ys = sin(Ls)*sin(Ts);
    zs = cos(Ls);  Xs = [xs;ys;zs];
    % paleo position vector
    X = A*Xs;  x = X(1);  
    y = X(2);  z = X(3);
    % calculate paleo longitude and colatitude
    cosL = z;  L = acos(z);
    T = atan(y/x)+pi*(x<0);  cosT = x/sin(L);  
    ez = X;  ey = [-cos(L)*cos(T); -cos(L)*sin(T); sin(L)];
    ex = [ey(2)*ez(3)-ey(3)*ez(2); ey(3)*ez(1)-ey(1)*ez(3); ey(1)*ez(2)-ey(2)*ez(1)];
    % calculate the direction vector
    Mx = 0;  My = sin(L);  Mz = -2*cos(L);
    M = Mx*ex+My*ey+Mz*ez;  
    M = M/sqrt(M'*M);  M = invA*M;
    % present declination and inclination
    ez = Xs;  ey = [-cos(Ls)*cos(Ts); -cos(Ls)*sin(Ts); sin(Ls)];
    ex = [ey(2)*ez(3)-ey(3)*ez(2); ey(3)*ez(1)-ey(1)*ez(3); ey(1)*ez(2)-ey(2)*ez(1)];
    Ip = -asin(M'*ez);  Mh = M-(M'*ez)*ez;  Mh = Mh/sqrt(Mh'*Mh);
    Mx = Mh'*ex;  anticlockwise = (Mx<0);
    Dp = 2*pi*anticlockwise + acos(Mh'*ey)*(1-2*anticlockwise);
    Dp = real(Dp);
end