function [xfit, yfit, zfit]=rectfit(x, y, z)

xyz=[x,y,z]';

fobj=planarFit(xyz);                        % Fit a plane to xyz data 

    R=fobj.R(:,[2,3,1])';
    Rxyz=R*xyz;                             % Rotate xyz coordinates to be parallel to xy plane
    z0=mean(Rxyz(3,:),2);

    x=Rxyz(1,:)'; y=Rxyz(2,:)'; 
    [rectx,recty,~,~] = minboundrect(x,y,'a');


    Fxyz(1,:)=rectx'; Fxyz(2,:)=recty'; 
    Fxyz(3,:)=z0;                           % re-insert z-coordinate
    xyzFit=R'*Fxyz;                         % rotate back to 3D 


    xfit=xyzFit(1,:)';
    yfit=xyzFit(2,:)';
    zfit=xyzFit(3,:)';

end
