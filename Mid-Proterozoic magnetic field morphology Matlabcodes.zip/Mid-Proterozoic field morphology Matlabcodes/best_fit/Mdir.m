function M = Mdir(L,T,D,I)
    ez = [ sin(L)*cos(T);  sin(L)*sin(T); cos(L)];  
    ey = [-cos(L)*cos(T); -cos(L)*sin(T); sin(L)];
    ex = [ey(2)*ez(3)-ey(3)*ez(2); ey(3)*ez(1)-ey(1)*ez(3); ey(1)*ez(2)-ey(2)*ez(1)];
    M = cos(I)*sin(D)*ex + cos(I)*cos(D)*ey - sin(I)*ez;    
end