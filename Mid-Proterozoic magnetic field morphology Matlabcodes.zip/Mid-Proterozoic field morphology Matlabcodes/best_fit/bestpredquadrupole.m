function [Tp,res] = bestpredquadrupole(Tn,Ln,data)
    % read the data
    lat = data(:,1);  Ls = (pi/180)*(90-lat);  
    lon = data(:,2);  Ts = (pi/180)*lon;
    Dm = (pi/180)*data(:,3);   
    Im = (pi/180)*data(:,4);
    err = (pi/180)*data(:,5);  
    rsq = err.^2;  ndata = length(lat);
    
    % make predictions and compare with data
    Tp = pi*(0.0:0.025:1.0);
    resa = zeros(size(Tp));
    resi = zeros(ndata,1);
    for i = 1:length(Tp)
        [A,invA] = transmatrix(Tn,Ln,Tp(i));
        for n = 1:ndata
            [Mp,~,~] = DI_paleo_quadrupole(A,invA,lat(n),lon(n));
            Mm = Mdir(Ls(n),Ts(n),Dm(n),Im(n));
            resi(n) = acos(Mp'*Mm);
        end
        resa(i) = 180/pi*sqrt((resi'*resi)/ndata);
    end
    [res,idx] = min(resa);  Tp = Tp(idx); 
end