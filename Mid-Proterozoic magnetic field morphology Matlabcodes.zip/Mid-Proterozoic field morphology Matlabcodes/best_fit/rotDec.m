function [Dec_rot]=rotDec(Slat,Slon,Dec,Elat,Elon,Eang)

arclen=5;
n=length(Slat);

Elat=Elat.*ones(n,1);
Elon=Elon.*ones(n,1);
Eang=Eang.*ones(n,1);

[Slat1,Slon1]=reckon(Slat,Slon,arclen,Dec);

[Slat_rot,Slon_rot]=Eulerrot(Slat, Slon, Elat, Elon, Eang);

[Slat1_rot,Slon1_rot]=Eulerrot(Slat1, Slon1, Elat, Elon, Eang);

Dec_rot=azimuth(Slat_rot,Slon_rot,Slat1_rot,Slon1_rot);

end