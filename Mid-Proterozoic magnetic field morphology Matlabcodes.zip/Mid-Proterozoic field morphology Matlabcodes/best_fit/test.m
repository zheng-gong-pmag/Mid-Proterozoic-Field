clear,  close,  clc,
Tn = 0;  Ln = 0;  Tp = 0;
[A,invA] = transmatrix(Tn,Ln,Tp);

lat = -90:2:90;  lon = 0:2:360;
[LAT,LON] = meshgrid(lat,lon);

for i = 1:length(lat)
    for j = 1:length(lon)
        [~,Dd(j,i),Id(j,i)] = DI_paleo_dipole(A,invA,lat(i),lon(j)); %#ok<SAGROW>
        [~,Dq(j,i),Iq(j,i)] = DI_paleo_quadrupole(A,invA,lat(i),lon(j)); %#ok<SAGROW>
    end
end

T = (pi/180)*LON;
L = (pi/180)*(90-LAT);  

Xp = sin(L).*cos(T);
Yp = sin(L).*sin(T);
Zp = cos(L);

figure(1)
set(gcf,'position',[0,0,800,800])
subplot(221)
surf(Xp,Yp,Zp,Id);  shading interp;
title('dipole inclination');
axis square; 
subplot(222)
surf(Xp,Yp,Zp,cos(Dd));  shading interp;
title('dipole declination');
axis square;
subplot(223)
surf(Xp,Yp,Zp,Iq);  shading interp;
title('quadrupole inclination');
axis square;
subplot(224)
surf(Xp,Yp,Zp,cos(Dq));  shading interp;
title('quadrupole declination');
axis square;