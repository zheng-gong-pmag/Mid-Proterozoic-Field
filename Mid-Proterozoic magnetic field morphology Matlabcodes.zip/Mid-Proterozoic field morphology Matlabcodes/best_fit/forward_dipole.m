clear; clc;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%% set age range, T1 < T2 %%%%%%%%%%%%%%%%%%%%%%%%%%

% T1 = 1740;  T2 = 1790;
T1 = 1425;  T2 = 1485;
% T1 = 1040;  T2 = 1095;
% T1 = 1400;  T2 = 1503;        % Sears

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% import plate polygons from shapefiles %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd('..');cd('plate_polygon')

Lau = shaperead('Laurentia.shp');
Bal = shaperead('Baltica.shp');
Al =  shaperead('Aldan.shp');
An =  shaperead('Anabar.shp');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% import paleomagnetic data %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd('..');cd('pmag_data')

D_Lau = readmatrix('Dir_Laurentia_all.csv','Range','D2:J38');
D_Bal = readmatrix('Dir_Baltica_all.csv','Range','D2:J38');
D_Al = readmatrix('Dir_Aldan_all.csv','Range','D2:J38');
D_An = readmatrix('Dir_Anabar_all.csv','Range','D2:J38');

% D_Lau = readmatrix('Sears_Laurentia.csv','Range','B2:H24');
% D_Bal = readmatrix('Sears_Baltica.csv','Range','B2:H24');
% D_Al = readmatrix('Sears_Aldan.csv','Range','B2:H24');
% D_An = readmatrix('Sears_Anabar.csv','Range','B2:H24');

Age_Lau=D_Lau(:,1); Slat_Lau=D_Lau(:,2); Slon_Lau=D_Lau(:,3);
Dec_Lau=D_Lau(:,4); Inc_Lau=D_Lau(:,5);
Err_Lau=D_Lau(:,6); Wgt_Lau=D_Lau(:,7);

Age_Bal=D_Bal(:,1); Slat_Bal=D_Bal(:,2); Slon_Bal=D_Bal(:,3);
Dec_Bal=D_Bal(:,4); Inc_Bal=D_Bal(:,5);
Err_Bal=D_Bal(:,6); Wgt_Bal=D_Bal(:,7);

Age_Al=D_Al(:,1); Slat_Al=D_Al(:,2); Slon_Al=D_Al(:,3);
Dec_Al=D_Al(:,4); Inc_Al=D_Al(:,5);
Err_Al=D_Al(:,6); Wgt_Al=D_Al(:,7);

Age_An=D_An(:,1); Slat_An=D_An(:,2); Slon_An=D_An(:,3);
Dec_An=D_An(:,4); Inc_An=D_An(:,5);
Err_An=D_An(:,6); Wgt_An=D_An(:,7);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% Euler rotation parameters %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% plates are rotated with respect to Laurentia reference frame %%%%%%

Elat_Lau=0;         Elon_Lau=0;         Eang_Lau=0.0;                       % Laurentia to absolute
Elat_Bal=47.5;      Elon_Bal=1.5;       Eang_Bal=49.0;                      % Baltica to Laurentia Evans+11
Elat_Al=78.0;       Elon_Al=118.3;      Eang_Al=170.7;                      % Aldan   to Laurentia Evans+11
Elat_An=78.0;       Elon_An=99.0;       Eang_An=147.0;                      % Anabar  to Laurentia Evans+11
% Elat_Al=61.0;       Elon_Al=317.0;      Eang_Al=81.0;                     % Aldan   to Laurentia Sears+22
% Elat_An=61.0;       Elon_An=317.0;      Eang_An=81.0;                     % Anabar  to Laurentia Sears+22
% Elat_Al=-67.3;      Elon_Al=-44.7;      Eang_Al=-151.5;                   % Aldan   to Laurentia Pisarevsky+14
% Elat_An=-70.0;      Elon_An=-46.8;      Eang_An=-127.0;                   % Anabar  to Laurentia Pisarevsky+14

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% start forward modeling to get best-fit field orientation %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd('..');cd('best_fit')

%%%%% rotate Slat, Slon and declination to Laurentia reference frame %%%%%%

[Slat_Lau_r,Slon_Lau_r]=Eulerrot(Slat_Lau,Slon_Lau,Elat_Lau,Elon_Lau,Eang_Lau);
[Dec_Lau_r]=rotDec(Slat_Lau,Slon_Lau,Dec_Lau,Elat_Lau,Elon_Lau,Eang_Lau);

[Slat_Bal_r,Slon_Bal_r]=Eulerrot(Slat_Bal,Slon_Bal,Elat_Bal,Elon_Bal,Eang_Bal);
[Dec_Bal_r]=rotDec(Slat_Bal,Slon_Bal,Dec_Bal,Elat_Bal,Elon_Bal,Eang_Bal);

[Slat_Al_r,Slon_Al_r]=Eulerrot(Slat_Al,Slon_Al,Elat_Al,Elon_Al,Eang_Al);
[Dec_Al_r]=rotDec(Slat_Al,Slon_Al,Dec_Al,Elat_Al,Elon_Al,Eang_Al);

[Slat_An_r,Slon_An_r]=Eulerrot(Slat_An,Slon_An,Elat_An,Elon_An,Eang_An);
[Dec_An_r]=rotDec(Slat_An,Slon_An,Dec_An,Elat_An,Elon_An,Eang_An);

%%%%%%%%%%%%%%%%%%%%%%%%%% data combination %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

D_Lau_r=[Age_Lau,Slat_Lau_r,Slon_Lau_r,Dec_Lau_r,Inc_Lau,Err_Lau,Wgt_Lau];
D_Bal_r=[Age_Bal,Slat_Bal_r,Slon_Bal_r,Dec_Bal_r,Inc_Bal,Err_Bal,Wgt_Bal];
D_Al_r=[Age_Al,Slat_Al_r,Slon_Al_r,Dec_Al_r,Inc_Al,Err_Al,Wgt_Al];
D_An_r=[Age_An,Slat_An_r,Slon_An_r,Dec_An_r,Inc_An,Err_An,Wgt_An];

%%%%%%%%%%%%%%%%%%% final input data to forward modeling %%%%%%%%%%%%%%%%%%

% DATA=D_Lau_r;                                          % Laurentia only
DATA=cat(1,D_Lau_r,D_Bal_r);                           % Laurentia + Baltica only
% DATA=cat(1,D_Lau_r,D_Al_r,D_An_r);                     % Laurentia + Siberia only
% DATA=cat(1,D_Lau_r,D_Bal_r,D_Al_r,D_An_r);             % Laurentia + Baltica + Siberia

%%%%%%%%%%%%%%%%%%% filter data based on age and weight %%%%%%%%%%%%%%%%%%%

DT = DATA(:,1);  DLAT = DATA(:,2);  DLON = DATA(:,3);
DD = DATA(:,4);  DI = DATA(:,5);    DERR = DATA(:,6);  DWT = DATA(:,7);
nidx = (DT<=T2).*(DT>=T1).*(DWT>0);  nidx = (nidx>0);
data = [DLAT(nidx),DLON(nidx),DD(nidx),DI(nidx),DERR(nidx)];

%%%%%%%%%%%%%%%%% calculate dec and inc errors based on a95 %%%%%%%%%%%%%%%

rad=pi/180;
DDERR=asin(sin(DERR.*rad)./cos(DI.*rad))./rad;
DIERR=DERR;

%%%%%%%%%%%%%%%%%%%%%%% calculate predicted residuals %%%%%%%%%%%%%%%%%%%%%

Tn = pi*(0.0:0.02:2.0);       % longitude grid
Ln = pi*(0.0:0.02:1.0);       % colatitude grid

[TN,LN] = meshgrid(Tn,Ln);
res = zeros(size(TN));

for i = 1:length(Tn)
    for j = 1:length(Ln)
        res(j,i) = bestpreddipole(Tn(i),Ln(j),data);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% figure 1 - residual map from forward modeling %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fig1=figure(1);
set(gcf,'position',[0,600,800,400])

Lat=(180/pi)*(pi/2-LN);
Lon=(180/pi)*TN;

s=pcolor(Lon,Lat,res);
% set(s, 'EdgeColor', 'none');
s.LineWidth = 0.3;
s.FaceColor = 'interp';
hold on

% lowbd=prctile(sort(res(:)),2.5);
% highbd=prctile(sort(res(:)),97.5);
% contour(Lon,Lat,res,0:lowbd:lowbd,'w','LineWidth',2);
% contour(Lon,Lat,res,0:highbd:highbd,'w','LineWidth',2);

title1=['Dipole Forward Modeling ' num2str(T2) '-' num2str(T1) ' Ma'];
title2=['minimum residual = ' num2str(min(res(:)),'%.1f') '°'];
t=title({title1 title2});
t.FontSize = 12;

xlabel('Longitude (°)'); ylabel('Latitude (°)');
xticks(0:60:360); yticks(-90:30:90);
clim([0,180]); hcb = colorbar; ylabel(hcb, 'Normalized RSS (°)');
ax = gca;
ax.FontSize = 10;

% plot Laurentia polygon
[r,~]=size(Lau);
for i=1:1:r
    plot(mod(Lau(i).X',360),Lau(i).Y','k','LineWidth',1.5);
end

% %% Baltica %%%
% [r,~]=size(Bal);
% for i=1:1:r
%    [tmp1,tmp2] = Eulerrot(Bal(i).Y', Bal(i).X', Elat_Bal, Elon_Bal, Eang_Bal);
%    u=(tmp2>300);
%    plot(tmp2(u),tmp1(u),'k','LineWidth',1.5);
% end
% 
% %% Aldan %%%
% [r,~]=size(Al);
% for i=1:1:r
%    [tmp1, tmp2] = Eulerrot(Al.Y', Al.X', Elat_Al, Elon_Al, Eang_Al);
%    plot(tmp2, tmp1,'k','LineWidth',1);
% end

% %%% Anabar %%%
% [r,~]=size(An);
% for i=1:1:r
%     [tmp1,tmp2] = Eulerrot(An(i).Y', An(i).X', Elat_An, Elon_An, Eang_An);
%     plot(tmp2,tmp1,'k','LineWidth',1);
% end

% plot data location
scatter(DLON(nidx),DLAT(nidx),40,'white','filled','MarkerEdgeColor','k','LineWidth',1.5);
hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% figure 2 - compare modeled and real declination and inclinations %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fig2=figure(2);
set(gcf,'position',[800,600,500,400])
t=sgtitle(['Dipole Forward Modeling ' num2str(T2) '-' num2str(T1) ' Ma']);
t.FontSize = 12;

TN = TN(:);  LN = LN(:);  Tp = 0;
res = res(:);  [~,idx] = min(res);
[A,invA] = transmatrix(TN(idx),LN(idx),Tp);
Dp = zeros(size(DLAT(nidx)));
Ip = zeros(size(DLAT(nidx)));

for n = 1:sum(nidx)
    [~,Dp(n),Ip(n)] = DI_paleo_dipole(A,invA,data(n,1),data(n,2));
end

subplot(1,2,1);
errorbar((1:1:n),DD(nidx),DDERR(nidx),'ko','LineWidth',1.5);  hold on;
plot((1:1:n),180/pi*Dp,'ro','LineWidth',1.5);
xlabel('Data #'); ylabel('Declination (°)');
xlim([0, n+1]); ylim([0,360]);
xticks(1:1:n); yticks(0:60:360);
title('Compare declination');
legend('data','prediction','Location','southwest')
ax = gca;
ax.FontSize = 10;

subplot(1,2,2);
errorbar((1:1:n),DI(nidx),DIERR(nidx),'ko','LineWidth',1.5);  hold on;
plot((1:1:n),180/pi*Ip,'ro','LineWidth',1.5);
xlabel('Data #'); ylabel('Inclination (°)');
xlim([0, n+1]); ylim([-90,90]);
xticks(1:1:n); yticks(-90:30:90);
title('Compare inclination');
ax = gca;
ax.FontSize = 10;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure 3 - plot best-fit field orientation with paleomagnetic directions%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fig3=figure(3);
set(gcf,'position',[0,0,600,600])

%%%%%%%%%%%%%%%%%%%%%% plot dipole field geometry %%%%%%%%%%%%%%%%%%%%%%%%%

lat = -90:1:90;  lon = 0:1:360;

[Lat,Lon] = meshgrid(lat,lon);

Dd=zeros(size(Lat));
Id=zeros(size(Lat));

for i = 1:length(lat)
    for j = 1:length(lon)
        [~,Dd(j,i),Id(j,i)] = DI_paleo_dipole(A,invA,lat(i),lon(j));
    end
end

Inc=Id/rad; Inclev=(-90:10:90);

axesm('MapProjection','ortho','Origin',[60 270 0],'Frame','on','Grid','on')
% axesm('MapProjection','robinson','Origin',[0 270 0],'Frame','on','Grid','on')

p=contourfm(Lat,Lon,Inc,Inclev);

clim([-90,90]); colormap(redblue); hcb = colorbar; ylabel(hcb, 'Inclination (°)');

hold on

%%%%%%%%%%%%%%%%%%%%%%%%%% plot plate polygons %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% plot Laurentia polygon
[r,~]=size(Lau);
for i=1:1:r
    [tmp1,tmp2] = Eulerrot(Lau(i).Y', Lau(i).X', Elat_Lau, Elon_Lau, Eang_Lau);
    plotm(tmp1,tmp2,'k','LineWidth',1);
end

% plot Baltica polygon
[r,~]=size(Bal);
for i=1:1:r
    [tmp1,tmp2] = Eulerrot(Bal(i).Y', Bal(i).X', Elat_Bal, Elon_Bal, Eang_Bal);
    plotm(tmp1,tmp2,'k','LineWidth',1);
end

% plot Aldan polygon
[r,~]=size(Al);
for i=1:1:r
    [tmp1, tmp2] = Eulerrot(Al.Y', Al.X', Elat_Al, Elon_Al, Eang_Al);
    plotm(tmp1, tmp2,'k','LineWidth',1);
end

% plot Anabar polygon
[r,~]=size(An);
for i=1:1:r
    [tmp1,tmp2] = Eulerrot(An(i).Y', An(i).X', Elat_An, Elon_An, Eang_An);
    plotm(tmp1,tmp2,'k','LineWidth',1);
end

hold on

% plot declinations

arclen=5;            % length of arrows

Slat1=data(:,1);Slon1=data(:,2);Dec=data(:,3);Inc=data(:,4);

[Slat2,Slon2]=reckon(Slat1,Slon1,arclen,Dec);

for i=1:1:length(Slat1)
    plotm([Slat1(i),Slat2(i)],[Slon1(i),Slon2(i)],'k-','LineWidth',2);
    scatterm(Slat1(i),Slon1(i),75,Inc(i),'filled','MarkerEdgeColor','k','LineWidth',2);
end


%%%%%%%%%%%%%%%%%%%%%%% calculate data coverage area %%%%%%%%%%%%%%%%%%%%%%

% get the boundary points

[xx,yy,zz] = sph2cart(rad*Slon1,rad*Slat1,ones(size(Slon1)));
bndy = convhull(xx,yy);

PTLAT = Slat1(bndy)';   PTLON = Slon1(bndy)';   N = length(PTLAT);

% fit the minimum bounding rectangular

[PTx, PTy, PTz]  = sph2cart(rad*PTLON, rad*PTLAT, ones(1,N));
[PTx_rect, PTy_rect, PTz_rect]=rectfit(PTx', PTy', PTz');

[ptLON,ptLAT,~] = cart2sph(PTx_rect, PTy_rect, PTz_rect);

ppLON = ptLON/rad; ppLAT = ptLAT/rad;

ppLON = mod(ppLON,360);
COVERAGE = areaint(ppLAT,ppLON);

rect_side1=distance(ppLAT(1),ppLON(1),ppLAT(2),ppLON(2));
rect_side2=distance(ppLAT(2),ppLON(2),ppLAT(3),ppLON(3));

% plot coverage area

plotm(ppLAT,ppLON,'w--','LineWidth',1.0);

title1=['Dipole Forward Modeling ' num2str(T2) '-' num2str(T1) ' Ma'];
title2=['minimum residual = ', num2str(min(res(:)),'%.1f') '°, covered area = ',num2str(100*COVERAGE,'%.1f'),'% Earth''s surface'];
t=title({title1 title2});
t.FontSize = 12;

% exort graphics
% exportgraphics(fig1,'residual_map.pdf','ContentType','vector')
% exportgraphics(fig2,'compare_directions.pdf','ContentType','vector')
% exportgraphics(fig3,'reconstruction.pdf','ContentType','vector')