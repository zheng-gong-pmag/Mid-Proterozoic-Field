function [A,invA] = transmatrix(Tn,Ln,Tp)
    % north pole ("z-axis")
    xn = sin(Ln)*cos(Tn);
    yn = sin(Ln)*sin(Tn);
    zn = cos(Ln);  Xn = [xn;yn;zn];
    % positive magnetic pole ("x-axis")
    ez = Xn;
    ex = [-cos(Ln)*cos(Tn);-cos(Ln)*sin(Tn);sin(Ln)];  
    ey = [ez(2)*ex(3)-ez(3)*ex(2); ez(3)*ex(1)-ez(1)*ex(3); ez(1)*ex(2)-ez(2)*ex(1)];
    Xp = cos(Tp)*ex + sin(Tp)*ey;
    % negative magnetic pole ("y-axis")
    xp = Xp(1);  yp = Xp(2);  zp = Xp(3);
    Xnp = -[yp*zn-yn*zp;zp*xn-zn*xp;xp*yn-xn*yp];
    % get the transpose matrix
    invA = [Xp,Xnp,Xn];
    A = invA\eye(3,3);
end